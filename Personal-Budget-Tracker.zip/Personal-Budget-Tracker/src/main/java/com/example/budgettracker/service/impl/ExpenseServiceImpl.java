package com.example.budgettracker.service.impl;

import com.example.budgettracker.dto.ExpenseDto;
import com.example.budgettracker.model.Expense;
import com.example.budgettracker.repository.ExpenseRepository;
import com.example.budgettracker.service.ExpenseService;
import com.example.budgettracker.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExpenseServiceImpl implements ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    @Override
    public Expense createExpense(String userId, ExpenseDto expenseDto) {
        Expense expense = new Expense();
        expense.setUserId(userId);
        expense.setCategoryId(expenseDto.getCategoryId());
        expense.setDescription(expenseDto.getDescription());
        expense.setAmount(expenseDto.getAmount());
        expense.setDate(expenseDto.getDate());
        return expenseRepository.save(expense);
    }

    @Override
    public List<Expense> getExpensesByUserId(String userId) {
        return expenseRepository.findByUserId(userId);
    }

    @Override
    public void deleteExpenseById(String userId, String expenseId) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id: " + expenseId));

        if (!expense.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to delete this expense.");
        }

        expenseRepository.deleteById(expenseId);
    }

    @Override
    public Expense updateExpense(String userId, String expenseId, ExpenseDto expenseDto) {
        Expense expense = expenseRepository.findById(expenseId)
                .orElseThrow(() -> new ResourceNotFoundException("Expense not found with id: " + expenseId));

        if (!expense.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to update this expense.");
        }

        // Update fields
        expense.setCategoryId(expenseDto.getCategoryId());
        expense.setAmount(expenseDto.getAmount());
        expense.setDescription(expenseDto.getDescription());
        expense.setDate(expenseDto.getDate());

        return expenseRepository.save(expense);
    }
}
