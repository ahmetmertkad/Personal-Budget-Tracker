package com.example.budgettracker.controller;

import com.example.budgettracker.dto.ExpenseDto;
import com.example.budgettracker.model.Expense;
import com.example.budgettracker.service.ExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/expenses")
public class ExpenseController {

    @Autowired
    private ExpenseService expenseService;

    @PostMapping("/create")
    public ResponseEntity<Expense> createExpense(@RequestBody ExpenseDto expenseDto,
                                                 @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        return ResponseEntity.ok(expenseService.createExpense(userId, expenseDto));
    }

    @GetMapping("/get")
    public ResponseEntity<List<Expense>> getExpensesByUserId(@AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        return ResponseEntity.ok(expenseService.getExpensesByUserId(userId));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteExpense(@PathVariable("id") String id,
                                              @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        expenseService.deleteExpenseById(userId, id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Expense> updateExpense(@PathVariable("id") String id,
                                                 @RequestBody ExpenseDto expenseDto,
                                                 @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        Expense updatedExpense = expenseService.updateExpense(userId, id, expenseDto);
        return ResponseEntity.ok(updatedExpense);
    }

}
