package com.example.budgettracker.controller;

import com.example.budgettracker.dto.CategoryDto;
import com.example.budgettracker.model.Category;
import com.example.budgettracker.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @PostMapping("/create")
    public ResponseEntity<Category> createCategory(@RequestBody CategoryDto categoryDto,
                                                   @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        return ResponseEntity.ok(categoryService.createCategory(userId, categoryDto));
    }

    @GetMapping("/get")
    public ResponseEntity<List<Category>> getCategoriesByUserId(@AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        return ResponseEntity.ok(categoryService.getCategoriesByUserId(userId));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable("id") String id, @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        categoryService.deleteCategoryById(userId, id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<Category> updateCategoryName(@PathVariable("id") String id,
                                                       @RequestBody CategoryDto categoryDto,
                                                       @AuthenticationPrincipal UserDetails userDetails) {
        String userId = userDetails.getUsername();
        Category updatedCategory = categoryService.updateCategoryName(userId, id, categoryDto);
        return ResponseEntity.ok(updatedCategory);
    }
}
