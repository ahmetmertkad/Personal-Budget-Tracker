package com.example.budgettracker.dto;

public class CategoryDto {
    private String name; // Name of the category

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
