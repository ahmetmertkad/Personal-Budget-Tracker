package com.example.budgettracker.service;

import com.example.budgettracker.dto.CategoryDto;
import com.example.budgettracker.model.Category;

import java.util.List;

public interface CategoryService {
    Category createCategory(String userId, CategoryDto categoryDto);
    List<Category> getCategoriesByUserId(String userId);
    void deleteCategoryById(String userId, String categoryId);
    Category updateCategoryName(String userId, String categoryId, CategoryDto categoryDto);
}
