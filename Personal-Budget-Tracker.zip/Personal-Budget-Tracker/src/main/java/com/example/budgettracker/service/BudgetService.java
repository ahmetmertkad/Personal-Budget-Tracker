package com.example.budgettracker.service;

import com.example.budgettracker.dto.BudgetDto;
import com.example.budgettracker.model.Budget;

import java.util.List;

public interface BudgetService {
    Budget createBudget(String userId, BudgetDto budgetDto);
    List<Budget> getBudgetsByUserId(String userId);
    List<Budget> getAllBudgets();
    void deleteBudgetById(String userId, String budgetId);
    Budget updateBudgetAmount(String userId, String budgetId, Double amount);
}

