package com.example.budgettracker.security;

public class SecurityConstants {
    public static final long JWT_EXPIRATION = 3600000;
}
