package com.example.budgettracker.service.impl;

import com.example.budgettracker.dto.BudgetDto;
import com.example.budgettracker.model.Budget;
import com.example.budgettracker.repository.BudgetRepository;
import com.example.budgettracker.service.BudgetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.budgettracker.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class BudgetServiceImpl implements BudgetService {

    @Autowired
    private BudgetRepository budgetRepository;

    @Override
    public Budget createBudget(String userId, BudgetDto budgetDto) {
        Budget budget = new Budget();
        budget.setUserId(userId);
        budget.setDate(budgetDto.getDate());
        budget.setDescription("Budget for " + budgetDto.getDate());
        budget.setAmount(budgetDto.getAmount());
        return budgetRepository.save(budget);
    }

    @Override
    public List<Budget> getBudgetsByUserId(String userId) {
        return budgetRepository.findByUserId(userId);
    }

    @Override
    public List<Budget> getAllBudgets() {
        return budgetRepository.findAll();
    }

    @Override
    public void deleteBudgetById(String userId, String budgetId) {
        Budget budget = budgetRepository.findById(budgetId)
                .orElseThrow(() -> new ResourceNotFoundException("Budget not found with id: " + budgetId));

        if (!budget.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to delete this budget.");
        }

        budgetRepository.deleteById(budgetId);
    }

    @Override
    public Budget updateBudgetAmount(String userId, String budgetId, Double amount) {
        Budget budget = budgetRepository.findById(budgetId)
                .orElseThrow(() -> new ResourceNotFoundException("Budget not found with id: " + budgetId));

        if (!budget.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to update this budget.");
        }

        // Update only the amount field
        budget.setAmount(amount);
        return budgetRepository.save(budget);
    }

}
