package com.example.budgettracker.service.impl;

import com.example.budgettracker.dto.CategoryDto;
import com.example.budgettracker.model.Category;
import com.example.budgettracker.repository.CategoryRepository;
import com.example.budgettracker.service.CategoryService;
import com.example.budgettracker.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public Category createCategory(String userId, CategoryDto categoryDto) {
        Category category = new Category();
        category.setUserId(userId);
        category.setName(categoryDto.getName());
        return categoryRepository.save(category);
    }

    @Override
    public List<Category> getCategoriesByUserId(String userId) {
        return categoryRepository.findByUserId(userId);
    }

    @Override
    public void deleteCategoryById(String userId, String categoryId) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + categoryId));

        if (!category.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to delete this category.");
        }

        categoryRepository.deleteById(categoryId);
    }
    @Override
    public Category updateCategoryName(String userId, String categoryId, CategoryDto categoryDto) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with id: " + categoryId));

        if (!category.getUserId().equals(userId)) {
            throw new IllegalArgumentException("You do not have permission to update this category.");
        }

        // Update the name
        category.setName(categoryDto.getName());
        return categoryRepository.save(category);
    }
}
