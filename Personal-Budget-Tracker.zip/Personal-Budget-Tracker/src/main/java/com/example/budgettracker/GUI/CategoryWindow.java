package com.example.budgettracker.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class CategoryWindow {
    private String jwtToken;
    private JTable categoryTable;
    private DefaultTableModel tableModel;

    public CategoryWindow(String token) {
        this.jwtToken = cleanToken(token); // Clean the token before using it

        JFrame frame = new JFrame("Category Management");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(700, 500);

        String[] columnNames = {"ID", "Name"};
        tableModel = new DefaultTableModel(columnNames, 0);
        categoryTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(categoryTable);
        JButton fetchButton = new JButton("Fetch Categories");
        JButton addButton = new JButton("Add Category");
        JButton updateButton = new JButton("Update Category");
        JButton deleteButton = new JButton("Delete Category");
        JButton mainButton = new JButton("Go back");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(fetchButton);
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(mainButton);

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        fetchButton.addActionListener(e -> fetchCategories());
        addButton.addActionListener(e -> addCategory());
        updateButton.addActionListener(e -> updateCategory());
        deleteButton.addActionListener(e -> deleteCategory());
        mainButton.addActionListener(e -> {
            frame.dispose();
            new MainWindow(jwtToken); // Open Category Management Window
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    /**
     * Utility method to clean the token by removing unnecessary formatting.
     *
     * @param token Raw token string
     * @return Cleaned token string
     */
    private String cleanToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            throw new IllegalArgumentException("Token cannot be null or empty");
        }
        return token.replaceAll("\\s+", "").replaceAll(".*\"token\":\"([^\"]+)\".*", "$1");
    }

    /**
     * Fetch all categories from the API and populate the table.
     */
    private void fetchCategories() {
        try {
            URL url = new URL("http://localhost:8080/api/categories/get");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                Scanner scanner = new Scanner(conn.getInputStream());
                StringBuilder jsonResponse = new StringBuilder();
                while (scanner.hasNextLine()) {
                    jsonResponse.append(scanner.nextLine());
                }
                scanner.close();

                org.json.JSONArray categories = new org.json.JSONArray(jsonResponse.toString());
                tableModel.setRowCount(0); // Clear the table
                for (int i = 0; i < categories.length(); i++) {
                    org.json.JSONObject category = categories.getJSONObject(i);
                    tableModel.addRow(new Object[]{
                            category.getString("id"),
                            category.getString("name")
                    });
                }
            } else {
                JOptionPane.showMessageDialog(null, "Failed to fetch categories. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching categories: " + e.getMessage());
        }
    }

    /**
     * Add a new category via the API.
     */
    private void addCategory() {
        try {
            String name = JOptionPane.showInputDialog("Enter Category Name:");
            if (name == null || name.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Category name is required.");
                return;
            }

            URL url = new URL("http://localhost:8080/api/categories/create");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            conn.setDoOutput(true);

            String jsonInput = String.format("{\"name\":\"%s\"}", name);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonInput.getBytes());
                os.flush();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                JOptionPane.showMessageDialog(null, "Category added successfully!");
                fetchCategories();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add category. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding category: " + e.getMessage());
        }
    }

    /**
     * Delete a selected category via the API.
     */
    private void deleteCategory() {
        try {
            int selectedRow = categoryTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(null, "Please select a category to delete.");
                return;
            }

            String categoryId = tableModel.getValueAt(selectedRow, 0).toString();

            int confirmation = JOptionPane.showConfirmDialog(null,
                    "Are you sure you want to delete this category?", "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION);

            if (confirmation != JOptionPane.YES_OPTION) {
                return; // User canceled the deletion
            }

            URL url = new URL("http://localhost:8080/api/categories/delete/" + categoryId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) {
                JOptionPane.showMessageDialog(null, "Category deleted successfully!");
                fetchCategories();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete category. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error deleting category: " + e.getMessage());
        }
    }

    private void updateCategory() {
        int selectedRow = categoryTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a category to update.");
            return;
        }

        String categoryId = tableModel.getValueAt(selectedRow, 0).toString();

        // Input for new category name
        String newName = JOptionPane.showInputDialog("Enter new category name:");
        if (newName == null || newName.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Category name is required.");
            return;
        }

        try {
            String jsonInput = String.format("{\"name\":\"%s\"}", newName);

            URL url = new URL("http://localhost:8080/api/categories/update/" + categoryId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonInput.getBytes());
                os.flush();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                JOptionPane.showMessageDialog(null, "Category updated successfully!");
                fetchCategories();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update category. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error updating category: " + e.getMessage());
        }
    }
}
