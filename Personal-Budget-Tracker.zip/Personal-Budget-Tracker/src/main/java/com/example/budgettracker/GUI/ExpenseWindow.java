package com.example.budgettracker.GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class ExpenseWindow {
    private String jwtToken;
    private JTable expenseTable;
    private DefaultTableModel tableModel;
    private ArrayList<String> categoryIds = new ArrayList<>();
    private ArrayList<String> categoryNames = new ArrayList<>();

    public ExpenseWindow(String token) {
        this.jwtToken = cleanToken(token);
        System.out.println("Cleaned JWT Token: " + jwtToken);

        JFrame frame = new JFrame("Expense Management");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(800, 500);

        String[] columnNames = {"ID", "Description", "Amount", "Date", "Category"};
        tableModel = new DefaultTableModel(columnNames, 0);
        expenseTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(expenseTable);
        JButton fetchButton = new JButton("Fetch Expenses");
        JButton addButton = new JButton("Add Expense");
        JButton updateButton = new JButton("Update Expense");
        JButton deleteButton = new JButton("Delete Expense");
        JButton mainButton = new JButton("Go back");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(fetchButton);
        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(mainButton);

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        fetchButton.addActionListener(e -> fetchExpenses());
        addButton.addActionListener(e -> addExpense());
        updateButton.addActionListener(e -> updateExpense());
        deleteButton.addActionListener(e -> deleteExpense());
        mainButton.addActionListener(e -> {
            frame.dispose();
            new MainWindow(jwtToken); // Open Category Management Window
        });

        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Fetch categories on load
        fetchCategories();
    }

    private String cleanToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            throw new IllegalArgumentException("Token cannot be null or empty");
        }
        return token.replaceAll("\\s+", "").replaceAll(".*\"token\":\"([^\"]+)\".*", "$1");
    }

    /**
     * Fetches categories from the server and stores them for dropdown use.
     */
    private void fetchCategories() {
        try {
            URL url = new URL("http://localhost:8080/api/categories/get");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            Scanner scanner = new Scanner(conn.getInputStream());
            StringBuilder jsonResponse = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonResponse.append(scanner.nextLine());
            }
            scanner.close();

            // Parse the JSON response
            org.json.JSONArray categories = new org.json.JSONArray(jsonResponse.toString());
            categoryIds.clear();
            categoryNames.clear();
            for (int i = 0; i < categories.length(); i++) {
                org.json.JSONObject category = categories.getJSONObject(i);
                categoryIds.add(category.getString("id"));
                categoryNames.add(category.getString("name"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching categories: " + e.getMessage());
        }
    }

    /**
     * Fetches expenses from the server and populates the table.
     */
    private void fetchExpenses() {
        try {
            URL url = new URL("http://localhost:8080/api/expenses/get");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            Scanner scanner = new Scanner(conn.getInputStream());
            StringBuilder jsonResponse = new StringBuilder();
            while (scanner.hasNextLine()) {
                jsonResponse.append(scanner.nextLine());
            }
            scanner.close();

            org.json.JSONArray expenses = new org.json.JSONArray(jsonResponse.toString());
            tableModel.setRowCount(0);

            for (int i = 0; i < expenses.length(); i++) {
                org.json.JSONObject expense = expenses.getJSONObject(i);
                String categoryId = expense.getString("categoryId");
                String categoryName = fetchCategoryName(categoryId); // Get category name using ID

                tableModel.addRow(new Object[]{
                        expense.getString("id"),
                        expense.getString("description"),
                        expense.getDouble("amount"),
                        expense.getString("date"),
                        categoryName
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error fetching expenses: " + e.getMessage());
        }
    }

    /**
     * Fetch category name by category ID.
     */
    private String fetchCategoryName(String categoryId) {
        for (int i = 0; i < categoryIds.size(); i++) {
            if (categoryIds.get(i).equals(categoryId)) {
                return categoryNames.get(i); // Return the matching category name
            }
        }
        return "Unknown"; // Fallback if no match found
    }

    /**
     * Adds a new expense entry to the server.
     */
    private void addExpense() {
        try {
            // Input for Description
            String description = JOptionPane.showInputDialog("Enter Description:");
            if (description == null || description.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Description is required.");
                return;
            }

            // Dropdowns for Year, Month, and Day
            String[] months = {"January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"};
            String[] years = {"2024", "2025", "2026"};
            String[] days = new String[31];
            for (int i = 1; i <= 31; i++) {
                days[i - 1] = String.format("%02d", i); // Format days as "01", "02", ..., "31"
            }

            JComboBox<String> monthBox = new JComboBox<>(months);
            JComboBox<String> yearBox = new JComboBox<>(years);
            JComboBox<String> dayBox = new JComboBox<>(days);

            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(3, 2));
            panel.add(new JLabel("Select Month:"));
            panel.add(monthBox);
            panel.add(new JLabel("Select Year:"));
            panel.add(yearBox);
            panel.add(new JLabel("Select Day:"));
            panel.add(dayBox);

            int result = JOptionPane.showConfirmDialog(null, panel, "Select Date",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result != JOptionPane.OK_OPTION) {
                return; // Exit if the user cancels
            }

            int monthIndex = monthBox.getSelectedIndex() + 1; // Convert 0-indexed month to 1-indexed
            String year = (String) yearBox.getSelectedItem();
            String month = String.format("%02d", monthIndex); // Format month as "01", "02", etc.
            String day = (String) dayBox.getSelectedItem();
            String date = year + "-" + month + "-" + day; // Combine year, month, and day

            // Input for Amount
            String amountStr = JOptionPane.showInputDialog("Enter Amount:");
            if (amountStr == null || amountStr.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Amount is required.");
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountStr);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid amount. Please enter a numeric value.");
                return;
            }

            // Dropdown for Category
            if (categoryNames.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No categories available. Please add categories first.");
                return;
            }

            String category = (String) JOptionPane.showInputDialog(
                    null,
                    "Select Category:",
                    "Category",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    categoryNames.toArray(),
                    categoryNames.get(0)
            );

            if (category == null) {
                JOptionPane.showMessageDialog(null, "Category selection is required.");
                return;
            }

            String categoryId = categoryIds.get(categoryNames.indexOf(category));

            // Prepare JSON payload
            String jsonInput = String.format(
                    "{\"description\":\"%s\", \"amount\":%.2f, \"date\":\"%s\", \"categoryId\":\"%s\"}",
                    description, amount, date, categoryId
            );

            // Send the POST request
            URL url = new URL("http://localhost:8080/api/expenses/create");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonInput.getBytes());
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                JOptionPane.showMessageDialog(null, "Expense added successfully!");
                fetchExpenses();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add expense. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error adding expense: " + e.getMessage());
        }
    }

    /**
     * Deletes the selected expense entry from the server.
     */
    private void deleteExpense() {
        try {
            int selectedRow = expenseTable.getSelectedRow();
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(null, "Select an expense to delete!");
                return;
            }

            String id = tableModel.getValueAt(selectedRow, 0).toString();
            URL url = new URL("http://localhost:8080/api/expenses/delete/" + id);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("DELETE");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_NO_CONTENT) {
                JOptionPane.showMessageDialog(null, "Expense deleted successfully!");
                fetchExpenses();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete expense. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error deleting expense: " + e.getMessage());
        }
    }

    private void updateExpense() {
        int selectedRow = expenseTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select an expense to update.");
            return;
        }

        String expenseId = (String) tableModel.getValueAt(selectedRow, 0);

        // Input for description
        String description = JOptionPane.showInputDialog("Enter new description:");
        if (description == null || description.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Description is required.");
            return;
        }

        // Dropdowns for Year, Month, and Day
        String[] months = {"January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"};
        String[] years = {"2024", "2025", "2026"};
        String[] days = new String[31];
        for (int i = 1; i <= 31; i++) {
            days[i - 1] = String.format("%02d", i); // Format days as "01", "02", ..., "31"
        }

        JComboBox<String> monthBox = new JComboBox<>(months);
        JComboBox<String> yearBox = new JComboBox<>(years);
        JComboBox<String> dayBox = new JComboBox<>(days);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        panel.add(new JLabel("Select Month:"));
        panel.add(monthBox);
        panel.add(new JLabel("Select Year:"));
        panel.add(yearBox);
        panel.add(new JLabel("Select Day:"));
        panel.add(dayBox);

        int result = JOptionPane.showConfirmDialog(null, panel, "Select Date",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            return; // Exit if the user cancels
        }

        int monthIndex = monthBox.getSelectedIndex() + 1; // Convert 0-indexed month to 1-indexed
        String year = (String) yearBox.getSelectedItem();
        String month = String.format("%02d", monthIndex); // Format month as "01", "02", etc.
        String day = (String) dayBox.getSelectedItem();
        String date = year + "-" + month + "-" + day; // Combine year, month, and day

        // Input for amount
        String amountStr = JOptionPane.showInputDialog("Enter new amount:");
        if (amountStr == null || amountStr.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Amount is required.");
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid amount. Please enter a numeric value.");
            return;
        }

        // Dropdown for category
        if (categoryNames.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No categories available. Please add categories first.");
            return;
        }

        String newCategory = (String) JOptionPane.showInputDialog(
                null,
                "Select New Category:",
                "Update Category",
                JOptionPane.QUESTION_MESSAGE,
                null,
                categoryNames.toArray(),
                categoryNames.get(0)
        );

        if (newCategory == null) {
            JOptionPane.showMessageDialog(null, "Category selection is required.");
            return;
        }

        String categoryId = categoryIds.get(categoryNames.indexOf(newCategory));

        try {
            String jsonInput = String.format(
                    "{\"categoryId\":\"%s\", \"amount\":%.2f, \"description\":\"%s\", \"date\":\"%s\"}",
                    categoryId, amount, description, date
            );

            URL url = new URL("http://localhost:8080/api/expenses/update/" + expenseId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("PUT");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + jwtToken);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonInput.getBytes());
                os.flush();
            }

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                JOptionPane.showMessageDialog(null, "Expense updated successfully!");
                fetchExpenses();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update expense. Response code: " + conn.getResponseCode());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error updating expense: " + e.getMessage());
        }
    }
}
